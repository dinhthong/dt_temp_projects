# Subtitle-Downloading-Python-Script(Linux)
A python script to download English subtitles for movies and TV.

You should have Python installed


Tutorial Video : https://www.youtube.com/watch?v=JoaWPGOC25w


Step 1 : Download the code from this repository (subd.py) and save on a folder somewhere you like

Step 2 : Set Up Command Aliases in Linux/Ubuntu/Debian

  Go to Home and Open ./bashrc file (ctrl+h :- to show hidden files)

  Just copy the below code in bottom of the file 
   
   alias subq='python your_python_file_location' 
  
  eg : alias subq='python       /home/basil/Videos/Latestsub/subd.py'
  
  and save
  
  
  Step 3 : Go to the movie folder where you need subtitle , Open the Termianl and Type "subq" (depends on your aliases).
  
  eg : If the  code you paste in ./bashrc is "   alias cool='python your_python_file_location'  " , your alias will be "cool"
  
  Step 4 : Copy and paste the movie name on the terminal and subtitle will be downloaded  and extracted to the movie folder within seconds.
